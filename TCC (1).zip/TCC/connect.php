<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "tcc";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "CREATE TABLE IF NOT EXISTS items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name CHAR(255) NOT NULL,
    quantity INT,
    price DECIMAL(20,2)
)";

// Execute query
if ($conn->query($sql) === TRUE) {

} else {
    echo "Error creating table: " . $conn->error;
}

// Close connection
$conn->close();
?>