<?php
		$servername = "localhost";
		$username = "root";
		$password = "";
		$database = "tcc";

		// Create connection
		$conn = new mysqli($servername, $username, $password, $database);

		// Check connection
		if ($conn->connect_error) {
			die("Connection failed: " . $conn->connect_error);
		}

		// SQL to retrieve data from the items table
		$sql = "SELECT * FROM items";
		$result = $conn->query($sql);

		if ($result->num_rows > 0) {
			echo "<table class = 't1'>
					<tr>
						<th>ID</th>
						<th>ItemName</th>
						<th>Quantity</th>
						<th>Price</th>
						<th colspan ='2'>Action</th>
					</tr>";

			// Output data using foreach
			while ($row = $result->fetch_assoc()) {
				echo "<tr>
					<td>" . $row["id"] . "</td>
					<td>" . $row["name"] . "</td>
					<td>" . $row["quantity"] . "</td>
					<td>" . $row["price"] . "</td>
					<td><button class='edit' data-id='" . $row["id"] . "'>Edit</button></td>
					<td><button class='delete' data-id='" . $row["id"] . "'>Delete</button></td>
        		</tr>";
			}

			echo "</table>";
		} else {
			echo "table is empty please add some items";
		}
	?>