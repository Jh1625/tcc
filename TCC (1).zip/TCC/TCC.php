<?php
 include 'connect.php'
?>


<!DOCTYPE html>
<html>
		
	<title>E-Commerce Asset Website</title>
	<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
   	<style>
        .t1, .t1 tr, .t1 td, .t1 th {
		margin-top:2vh;
            border: 1px solid black;
        }

		.popup-overlay, .popup-overlay2 {
			visibility:hidden;
		}

		.popup-content, .popup-content2 {
			visibility:hidden;
		}
		.popup-overlay .active {
			visibility:visible;
		}

		.popup-content .active {
			visibility:visible;
		}

		.popup-overlay2 .active {
			visibility:visible;
		}

		.popup-content2 .active {
			visibility:visible;
		}
   	</style>


	<head><h1> E-commerce </h1> </head>
	<body>
	<?php include 'showtable.php'?>
		<button type="button" style = "margin:1vh 24vh" id = "additem">Add Item</button>

		<div class="popup-overlay">
			<div class="popup-content">
				<form method = "POST" action="additem.php">
					<table>
						<tr>
							<td>Item name:</td>
							<td><input type = text name = "name"></td>
						</tr>
						<tr>
							<td>Item quantity:</td>
							<td><input type = text name = "quantity"></td>
						</tr>
						<tr>
							<td>Item price:</td>
							<td><input type = text name = "price"></td>
						</tr>
					</table>
					<input type = "submit" style = "margin:1vh 24vh">
				</form>
				<button class="close">Close</button>    
			</div>
		</div>

		<div class="popup-overlay2">
			<div class="popup-content2">
				<table>
					<tr>
						<input type = hidden name = "itemid">
						<td>Item name:</td>
						<td><input type = text name = "itemname"></td>
					</tr>
					<tr>
						<td>Item quantity:</td>
						<td><input type = text name = "itemquantity"></td>
					</tr>
					<tr>
						<td>Item price:</td>
						<td><input type = text name = "itemprice"></td>
					</tr>
				</table>
				<button id = "updateItem" style = "margin:1vh">Update</button>
				<button class="close2">Close</button>    
			</div>
		</div>

		


	</body>
	
</html>




<script type ="text/javascript">

	$(document).ready(function () {
		$("#additem").on("click", function(){
			$("input[name='name']").val('');
			$("input[name='quantity']").val('');
			$("input[name='price']").val('');
			$(".popup-overlay, .popup-content").addClass("active");
			$(".close2").click();
		});


		$(".close").on("click", function(){
			$(".popup-overlay, .popup-content").removeClass("active");
		});

		$(".close2").on("click", function(){
			$(".popup-overlay2, .popup-content2").removeClass("active");
		});

		$(".delete").on("click", function () {
            var itemId = $(this).data("id");
            var confirmDelete = confirm("Are you sure you want to delete this item?");
            if (confirmDelete) {
                // Send AJAX request to delete.php
                $.ajax({
                    type: "POST",
                    url: "delete.php",
                    data: { id: itemId },
                    success: function (data) {
                        console.log(data);
                        location.reload();
                    },
                    error: function (error) {
                        console.error("Error deleting item: " + error);
                    }
                });
            }
        });

		$(".edit").on("click", function () {
			var row = $(this).closest("tr");
			var itemId = $(this).data("id");

			// Retrieve item details for the selected row
			var itemID = row.find("td:eq(0)").text();
			var itemName = row.find("td:eq(1)").text();
			var itemQuantity = row.find("td:eq(2)").text();
			var itemPrice = row.find("td:eq(3)").text();

			// Populate the form fields with the retrieved data
			$("input[name='itemid']").val(itemID);
			$("input[name='itemname']").val(itemName);
			$("input[name='itemquantity']").val(itemQuantity);
			$("input[name='itemprice']").val(itemPrice);

			// Display the popup for editing
			$(".popup-overlay2, .popup-content2").addClass("active");
			$(".close").click();

		});

		$("#updateItem").on("click", function () {
			$.ajax({
				type: "POST",
				url: "updateitem.php",
				data: {
					id: $("input[name='itemid']").val(),
					name: $("input[name='itemname']").val(),
					quantity: $("input[name='itemquantity']").val(),
					price: $("input[name='itemprice']").val()
				},
				success: function (data) {
					console.log(data);
					location.reload(true);
				},
				error: function (error) {
					console.error("Error updating item: " + error);
				}
			});
    	});

		
	});
	
</script>

